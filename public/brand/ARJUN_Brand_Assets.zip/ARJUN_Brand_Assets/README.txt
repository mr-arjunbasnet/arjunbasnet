ARJUN brand assets — Variant Aurora (v1.0, September 2026)
Arjun Basnet · arjun-basnet.com.np · mr.arjunbasnet@gmail.com

Folders
 01_Logo_Primary_Stacked     Mark + wordmark + slogan. Default logo.
 02_Logo_Horizontal          Mark + wordmark + slogan, wide lockup.
 03_Logo_Horizontal_Compact  Mark + wordmark, no slogan. Use below 220 px wide.
 04_Logomark                 The mark alone, tight square.
 05_Wordmark                 Wordmark with and without slogan.
 06_App_Icons                Aurora / light / dark; rounded + square; iOS sizes; Android adaptive layers.
 07_Favicons                 favicon.ico, favicon.svg, PNG 16–512, apple-touch-icon, site.webmanifest, head-snippet.html
 08_Social                   Avatars and covers: LinkedIn, X, Facebook, YouTube, Open Graph.
 09_Watermark                Mark at 100%, 25% and 15% opacity.
 10_Colors                   arjun-colors.css / .json, ARJUN.ase (Adobe), ARJUN.gpl (GIMP), palette sheet.
 11_Fonts                    Montserrat variable (TTF, WOFF2) + licence.
 12_Guidelines               ARJUN_Brand_Guidelines.pdf

Colourways (file suffix)
 _full      gradient mark, gradient wordmark  → on Warm White / white
 _reversed  gradient mark, white wordmark     → on Night / dark
 _white     all white                         → on Aurora gradient or photography
 _indigo    one colour, Deep Indigo #221A5C   → documents, embossing
 _black     one colour, black                 → single-ink print

Formats
 SVG   vector, for design tools, web and print.
 PNG   transparent background. Widths 1000 / 2000 / 4000 px (logos), 256–2048 px (mark).
 JPEG  no transparency; supplied on the correct background for each colourway.
